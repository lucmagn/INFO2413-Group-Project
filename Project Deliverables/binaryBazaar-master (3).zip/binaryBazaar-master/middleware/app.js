var item = require("../models/item");
var comment = require("../models/comment");
//all middleware goes here
var middlewareObj = {};

middlewareObj.checkOwnItem = function(req, res, next){
    if(req.isAuthenticated()){
        
        item.findById(req.params.id, function(err, foundItem){
            if(err){
                req.flash("error", "The Item in question has been misplaced");
                res.redirect("back");
            } else {
                if(foundItem.author.id.equals(req.user._id)){
                    next();
                } else {
                    req.flash("error", "That doesn't belong to you");
                    res.redirect("back");
                }
            }
        });
    } else {
        req.flash("error", "You need to be logged in to do that");
        res.redirect("back");
    }
    
};

middlewareObj.checkOwnComment = function(req, res, next){
    if(req.isAuthenticated()){
        
        comment.findById(req.params.comment_id, function(err, foundComment){
            if(err){
                req.flash("error", "The Comment in question has been misplaced");                
                res.redirect("back");
            } else {
                if(foundComment.author.id.equals(req.user._id)){
                    next();
                } else {
                    req.flash("error", "That doesn't belong to you");
                    res.redirect("back");
                }
            }
        });
    } else {
        req.flash("error", "You need to be logged in to do that");
        res.redirect("back");
    }
    
};

middlewareObj.isLoggedIn = function(req, res, next){
    if(req.isAuthenticated()){
        return next();
    }
    req.flash("error", "You need to be logged in to do that");
    res.redirect("/login");
    
};

module.exports = middlewareObj;