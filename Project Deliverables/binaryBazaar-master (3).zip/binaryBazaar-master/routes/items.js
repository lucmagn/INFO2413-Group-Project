var express = require("express");
var router = express.Router();
var item = require("../models/item");
var middleware = require("../middleware/app.js");

//CREATE
router.post("/", middleware.isLoggedIn, function(req, res){
    var name = req.body.name;
    var image = req.body.image;
    var description = req.body.description;
    var author = {
        id: req.user._id,
        username: req.user.username
    };
    var price = req.body.price;
    var newItem = {name:name, image:image, description:description, author:author, price:price};
    item.create(newItem, function(err, item){
        if(err){
            console.log(err);
        } else {
            req.flash("success", "Item added successfully");
            res.redirect("/");
        }
    });
});

//NEW
router.get("/:profile/newItem", middleware.isLoggedIn, function(req, res){
    res.render("items/newItem.ejs");
});

//SHOW
router.get("/item/:id", function(req, res){
    //find item with provided id
    item.findById(req.params.id).populate("comments").exec(function(err, foundItem){
        if(err){
            console.log(err);
        } else {
            res.render("items/showItem", {item: foundItem});
        }
    });
});

// EDIT
router.get("/item/:id/edit", middleware.checkOwnItem, function(req, res){
    
    item.findById(req.params.id, function(err, foundItem){
        if(err){
            console.log(err);
        } else {
            res.render("items/editItem", {item: foundItem});
        }
    });
 });

// UPDATE
router.put("/item/:id", middleware.checkOwnItem, function(req,res){
    item.findByIdAndUpdate(req.params.id, req.body.item, function(err, updatedItem){
        if(err){
            res.redirect("/item/" +req.params.id);
        } else {
            req.flash("success", "Item updated successfully");
            res.redirect("/item/" +req.params.id);
        }
    });
});

// DESTROY
router.delete("/item/:id", middleware.checkOwnItem, function(req,res){
    item.findByIdAndRemove(req.params.id, function(err){
        if(err){
            res.redirect("/");
        } else {
            req.flash("success", "Item removed successfully");
            res.redirect("/");
        }
    });
});

module.exports = router;