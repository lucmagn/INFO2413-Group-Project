var express = require("express");
var router = express.Router();
var item = require("../models/item");
var comment = require("../models/comment");
var middleware = require("../middleware/app.js");

//===================
// COMMENTS ROUTES
//===================

//NEW
router.get("/item/:id/comment/new", middleware.isLoggedIn, function(req, res){
    item.findById(req.params.id, function(err, item){
        if(err){
            console.log(err);
        } else {
            res.render("comments/newComment", {item: item});
        }
    });
});

//CREATE
router.post("/item/:id/comment", middleware.isLoggedIn, function(req, res){
    item.findById(req.params.id, function(err, item){
            if(err){
                console.log(err);
            } else {
                comment.create(req.body.comment, function(err, comment){
                    if(err){
                        console.log(err);
                    } else {
                        //add username and id to comment and save
                        comment.author.id = req.user._id;
                        comment.author.username = req.user.username;
                        comment.save();
                        item.comments.push(comment);
                        item.save();
                        req.flash("success", "Comment added successfully");
                        res.redirect("/item/"+ item._id);
                    }
                });
                
            }
       });
});

// EDIT
router.get("/item/:id/comment/:comment_id/edit", middleware.checkOwnComment, function(req, res){
    comment.findById(req.params.comment_id, function(err, foundComment){
        if(err){
            res.redirect("back");
        } else {
            res.render("comments/editComment", {item_id: req.params.id, comment: foundComment});
        }
    });
});

// UPDATE
router.put("/item/:id/comment/:comment_id", middleware.checkOwnComment, function(req, res){
    comment.findByIdAndUpdate(req.params.comment_id, req.body.comment, function(err, updatedComment){
        if(err){
            res.redirect("back");
        } else {
            req.flash("success", "Comment updated successfully");
            res.redirect("/item/" + req.params.id);
        }
    });
});

// DESTROY 
router.delete("/item/:id/comment/:comment_id", middleware.checkOwnComment, function(req, res){
    comment.findByIdAndRemove(req.params.comment_id, function(err){
        if(err){
            res.redirect("back");
        } else {
            req.flash("success", "Comment removed successfully");
            res.redirect("/item/" + req.params.id);
        }
    });
});

module.exports = router;