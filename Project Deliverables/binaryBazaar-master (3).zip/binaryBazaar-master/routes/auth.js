var express = require("express");
var router = express.Router();
var item = require("../models/item");
var user = require("../models/user");
var cart = require("../models/cart");
var passport = require("passport");

//INDEX
router.get("/", function(req, res){
    item.find({}, function(err, items){
        if(err){
            console.log(err);
        } else {
            res.render("items/index", {items:items, user: req.user});
        }
    });
});



// ===============
// AUTH ROUTES
// ===============

// NEW user
router.get("/register", function(req, res){
    res.render("auth/register");
});

// CREATE user
router.post("/register", function(req, res){
    var newUser = new user({username: req.body.username});
    user.register(newUser, req.body.password, function(err, user){
        if(err){
            req.flash("error", err.message);
            console.log(err);
            return res.render("auth/register");
        }
        passport.authenticate("local")(req, res, function(){
            req.flash("success", "Welcome to Binary Bazaar " + user.username + " !!!");
            res.redirect("/");
        });
    });
});

// SHOW LOGIN
router.get("/login", function(req, res){
    res.render("auth/login");
});

// CREATE LOGIN
router.post("/login", passport.authenticate("local", {successRedirect: "/", failureRedirect: "/login"}), function(req, res){
});

// LOGOUT
router.get("/logout", function(req, res){
    req.logout();
    req.flash("success", "Logged out successfully");
    res.redirect("/");
});


module.exports = router;