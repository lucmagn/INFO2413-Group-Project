var express = require("express");
var router = express.Router();
var item = require("../models/item");
var user = require("../models/user");
var middleware = require("../middleware/app.js");
var Cart = require("../models/cart");

    //ADD TO CART
    router.get("/add-to-cart/:id", function(req, res, next){
        var productId = req.params.id;
        var cart = new Cart(req.session.cart ? req.session.cart : {});
        
        item.findById(productId, function(err, item){
            if (err) {
                return res.redirect("/");
            }
            cart.add(item, item.id);
            req.session.cart = cart;
            console.log(req.session.cart);
            req.flash("success", item.name + " added to cart successfully");
            res.redirect("/item/" + item.id);
        });
    });
    
    //SHOW
    router.get("/shopping-cart", function(req, res, next) {
        if (!req.session.cart) {
            return res.render("cart/showCart", {items: null});
        }
        var cart = new Cart(req.session.cart);
        res.render("cart/showCart", {items: cart.generateArray(), totalPrice: cart.totalPrice});
    });
    
    //SHOW CHECKOUT
    router.get("/checkout", function(req, res, next){
        if (!req.session.cart) {
            return res.redirect("/shopping-cart");
        }
        var cart = new Cart(req.session.cart);
        res.render("cart/checkout", {total: cart.totalPrice});
    });
    
    
    module.exports = router;