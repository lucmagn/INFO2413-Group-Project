var express     = require("express"),
    app         = express(),
    bodyParser  = require("body-parser"),
    mongoose    = require("mongoose"),
    flash       = require("connect-flash"),
    session     = require("express-session"),
    mongoStore  = require("connect-mongo")(session),
    passport    = require("passport"),
    LocalStrategy = require("passport-local"),
    methodOverride = require("method-override"),
    item        = require("./models/item"),
    comment     = require("./models/comment"),
    user        = require("./models/user"),
    cart        = require("./models/cart"),
    seedDB      = require("./seeds");
    
var commentRoutes = require("./routes/comments"),
    itemRoutes    = require("./routes/items"),
    authRoutes    = require("./routes/auth"),
    cartRoutes    = require("./routes/cart");

mongoose.connect("mongodb://localhost/binaryBazaar");
app.use(bodyParser.urlencoded({extended:true}));
app.set("view engine", "ejs");
app.use(express.static(__dirname + "/public"));
app.use(methodOverride("_method"));
app.use(flash());
//seedDB();

// PASSPORT CONFIG
app.use(session({
    secret: "imdabes",
    resave: false,
    saveUninitialized: false,
    store: new mongoStore({ mongooseConnection: mongoose.connection}),
    cookie: { maxAge: 180 * 60 * 1000 }
}));
app.use(passport.initialize());
app.use(passport.session());
passport.use(new LocalStrategy(user.authenticate()));
passport.serializeUser(user.serializeUser());
passport.deserializeUser(user.deserializeUser());

app.use(function(req, res, next){
    res.locals.user = req.user;
    res.locals.error = req.flash("error");
    res.locals.success = req.flash("success");
    res.locals.session = req.session;
    next();
});

app.use(authRoutes);
app.use(itemRoutes);
app.use(commentRoutes);
app.use(cartRoutes);


app.listen(process.env.PORT, process.env.IP, function(){
    console.log("Binary Bazaar Server Running...");
});
