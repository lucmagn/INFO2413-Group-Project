var mongoose = require("mongoose");
var item = require("./models/item");
var comment = require("./models/comment");

var data = [ 
    {
        name: "Tempest",
        image: "https://images.unsplash.com/photo-1472978346569-9fa7ea7adf4a?dpr=1&auto=compress,format&fit=crop&w=1199&h=799&q=80&cs=tinysrgb&crop=",
        description: "I'm drowning deeper in fears and failures"
    },
    
    {
        name: "Hour of need",
        image: "https://images.unsplash.com/photo-1421151051865-b98b5f93dc13?dpr=1&auto=compress,format&fit=crop&w=376&h=251&q=80&cs=tinysrgb&crop=",
        description: "in shadows and tall trees"
    },
    
    {
        name: "Focus",
        image: "https://images.unsplash.com/photo-1490810194309-344b3661ba39?dpr=1&auto=compress,format&fit=crop&w=376&h=190&q=80&cs=tinysrgb&crop=",
        description: "bring the fury"
    }
]

function seedDB(){
    //remove item
    item.remove({}, function(err){
        if(err){
            console.log(err);
        } else {
            console.log("removed items");
                //add items
            data.forEach(function(seed){
                item.create(seed, function(err, item){
                    if(err){
                        console.log(err);
                    } else {
                        console.log("added item");
                        //add comments
                        comment.create(
                            {
                                text: "good quality!",
                                author: "ben"
                            }, function(err, comment){
                                if(err){
                                    console.log(err);
                                } else {
                                    item.comments.push(comment);
                                    item.save();
                                    console.log("created new comments")
                                }
                        });
                    }
                });
            });
        }
    });
    

}

module.exports = seedDB;